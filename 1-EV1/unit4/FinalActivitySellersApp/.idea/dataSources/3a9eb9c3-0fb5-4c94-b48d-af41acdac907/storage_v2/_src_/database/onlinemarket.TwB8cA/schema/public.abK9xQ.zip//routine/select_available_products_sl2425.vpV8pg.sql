create function select_available_products_sl2425(cif character varying, categoryid integer) returns SETOF products
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT p.*
        FROM products p
        WHERE p.category_id = categoryId
          AND p.active = TRUE
          AND p.product_id NOT IN ( SELECT sp.product_id
                                    FROM seller_products sp, sellers sell
                                    WHERE sp.seller_id = sell.seller_id
                                      AND  cif1 = sell.cif
        );
END;
$$;

alter function select_available_products_sl2425(varchar, integer) owner to postgres;

