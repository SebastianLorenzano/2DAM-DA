create function employee_list_by_name(p_name character varying, p_wildcard character varying DEFAULT ''::character varying) returns SETOF employee
    language plpgsql
as
$$DECLARE r_name VARCHAR;
BEGIN
	IF p_wildcard = 'a%' THEN	
		r_name := p_name || '%';
	ELSIF p_wildcard = '%a' THEN
		r_name := '%' || p_name;
	ELSIF p_wildcard = '%a%' THEN
		r_name := '%' || p_name || '%';
	ELSE
		r_name := p_name;
	END IF;
	RETURN QUERY SELECT * FROM employee WHERE ename ILIKE r_name;
END;$$;

alter function employee_list_by_name(varchar, varchar) owner to postgres;

