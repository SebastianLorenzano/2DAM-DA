create function has_pending_subjects(student_idcard character varying) returns boolean
    language plpgsql
as
$$
DECLARE
 pending_subjects INTEGER; 
BEGIN
 	SELECT COUNT(*) INTO pending_subjects 
	FROM scores INNER JOIN enrollments ON enrollments.code=scores.enrollment_id
	WHERE (enrollments.student LIKE student_idcard) AND (scores.score < 5);
   RETURN (pending_subjects > 0); 
END;
$$;

alter function has_pending_subjects(varchar) owner to postgres;

