create function employee_list_by_job(p_job character varying)
    returns TABLE(o_empno integer, o_ename character varying, o_job character varying, o_deptno integer)
    language plpgsql
as
$$
BEGIN
	RETURN QUERY SELECT empno, ename, job, deptno FROM employee WHERE job ILIKE p_job;
END;
$$;

alter function employee_list_by_job(varchar) owner to postgres;

