create function get_student_scores(p_student_id character varying)
    returns TABLE(course_name character varying, subject_name character varying, final_score integer)
    language plpgsql
as
$$
DECLARE
 mysubject RECORD; 
BEGIN
 FOR mysubject IN 
 	SELECT subjects.name AS tname, courses.name AS tcourse, scores.score as tscore
      FROM courses INNER JOIN (subjects INNER JOIN (scores INNER JOIN enrollments ON scores.enrollment_id=enrollments.code) ON subjects.code=scores.subject_id) ON subjects.course=courses.code
	WHERE enrollments.student LIKE p_student_id 
   LOOP 
		subject_name := mysubject.tname;
		course_name := mysubject.tcourse;
		final_score := mysubject.tscore;
   RETURN NEXT; 
 END LOOP; 
END;
$$;

alter function get_student_scores(varchar) owner to postgres;

