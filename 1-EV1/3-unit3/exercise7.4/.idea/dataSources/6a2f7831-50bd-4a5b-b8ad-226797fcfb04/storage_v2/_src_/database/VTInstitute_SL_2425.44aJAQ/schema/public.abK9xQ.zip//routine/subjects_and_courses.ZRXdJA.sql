create function subjects_and_courses(theyear integer) returns SETOF subjects_with_courses
    language plpgsql
as
$$
DECLARE
 mysubject subjects_with_courses; 
BEGIN
 FOR mysubject IN 
 	SELECT subjects.name, courses.name FROM subjects INNER JOIN courses 
	ON subjects.course=courses.code
	WHERE year=theyear 
   LOOP 
   RETURN NEXT mysubject; 
 END LOOP; 
END;
$$;

alter function subjects_and_courses(integer) owner to postgres;

