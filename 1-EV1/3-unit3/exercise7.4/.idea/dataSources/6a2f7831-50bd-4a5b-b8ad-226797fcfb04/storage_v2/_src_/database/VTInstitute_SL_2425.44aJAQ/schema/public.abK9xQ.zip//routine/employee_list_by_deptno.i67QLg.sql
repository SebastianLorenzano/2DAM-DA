create function employee_list_by_deptno(p_deptno integer) returns SETOF employee
    language plpgsql
as
$$BEGIN
	RETURN QUERY SELECT * FROM employee WHERE deptno = p_deptno;
END;$$;

alter function employee_list_by_deptno(integer) owner to postgres;

