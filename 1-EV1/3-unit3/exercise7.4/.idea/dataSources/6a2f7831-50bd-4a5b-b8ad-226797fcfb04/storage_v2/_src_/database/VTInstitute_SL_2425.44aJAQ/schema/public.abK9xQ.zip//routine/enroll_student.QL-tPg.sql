create procedure enroll_student(IN student_id character varying, IN course_id integer)
    language plpgsql
as
$$
DECLARE
 	enroll_code INTEGER;
	mysubject subjects;
BEGIN
   INSERT INTO enrollments (student, course) 
          VALUES (student_id, course_id)
		  RETURNING code INTO enroll_code;
   FOR mysubject IN
   		SELECT * FROM subjects where course=course_id
   LOOP
   		INSERT INTO scores (enrollment_id, subject_id, score)
		       VALUES (enroll_code, mysubject.code, 0);
   END LOOP;
END;
$$;

alter procedure enroll_student(varchar, integer) owner to postgres;

