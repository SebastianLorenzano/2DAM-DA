create function listofsubjects(theyear integer) returns SETOF subjects
    language plpgsql
as
$$
DECLARE
 mysubject subjects; 
BEGIN
 FOR mysubject IN SELECT * FROM subjects WHERE year=theyear LOOP 
   RETURN NEXT mysubject; 
 END LOOP; 
END;
$$;

alter function listofsubjects(integer) owner to postgres;

