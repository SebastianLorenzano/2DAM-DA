create function subjectsinayear(theyear integer) returns integer
    language plpgsql
as
$$
DECLARE
 amount INTEGER; 
BEGIN
 SELECT COUNT(*) INTO amount FROM subjects WHERE subjects.year=theyear; 
 RETURN amount; 
END;
$$;

alter function subjectsinayear(integer) owner to postgres;

