create function subjects_and_courses_2(theyear integer)
    returns TABLE(name character varying, course character varying)
    language plpgsql
as
$$
DECLARE
 mysubject RECORD; 
BEGIN
 FOR mysubject IN 
 	SELECT subjects.name AS sname, courses.name AS scourse
      FROM subjects INNER JOIN courses ON subjects.course=courses.code
	WHERE year=theyear 
   LOOP 
   name := mysubject.sname;
   course := mysubject.scourse;
   RETURN NEXT; 
 END LOOP; 
END;
$$;

alter function subjects_and_courses_2(integer) owner to postgres;

